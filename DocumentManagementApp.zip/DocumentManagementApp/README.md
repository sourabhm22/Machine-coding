## Getting Started
This code runs on loop showing menu and ask user to enter command in any order and terminates with option 11

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

- src/App contains main method and is the driver class
- src/Entity contains User and Document Entity
- src/Service contains User and Document Service Interface and its implementation
