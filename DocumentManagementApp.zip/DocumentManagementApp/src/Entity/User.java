package Entity;
import java.util.*;

public class User {
    private final String id;
    private final String name;
    private final String password;
    private final Set<String> documentIds;

    public User(String id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.documentIds = new HashSet<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean authenticate(String password) {
        return this.password.equals(password);
    }

    public void addDocument(String documentId) {
        documentIds.add(documentId);
    }

    public boolean ownsDocument(String documentId) {
        return documentIds.contains(documentId);
    }
}