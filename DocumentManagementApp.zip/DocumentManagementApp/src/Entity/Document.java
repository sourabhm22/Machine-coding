package Entity;

import java.time.LocalDateTime;
import java.util.*;

public class Document {
    private final String id;
    private final String ownerId;
    private final List<String> versions;
    private final List<LocalDateTime> timestamps;

    public Document(String id, String ownerId, String content) {
        this.id = id;
        this.ownerId = ownerId;
        this.versions = new ArrayList<>();
        this.timestamps = new ArrayList<>();
        this.versions.add(content);
        this.timestamps.add(LocalDateTime.now());
    }

    public String getId() {
        return id;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public String getOwnerNameString() {
        return getOwnerId();
    }

    public String getCurrentVersion() {
        return versions.get(versions.size() - 1);
    }

    public LocalDateTime getCurrentTimestamp() {
        return timestamps.get(timestamps.size() - 1);
    }

    public void addVersion(String content) {
        versions.add(content);
        timestamps.add(LocalDateTime.now());
    }

    public String getVersion(int versionIndex) {
        if (versionIndex < 0 || versionIndex >= versions.size()) {
            throw new IndexOutOfBoundsException("Invalid version index");
        }
        return versions.get(versionIndex);
    }

    public LocalDateTime getTimestamp(int versionIndex) {
        if (versionIndex < 0 || versionIndex >= timestamps.size()) {
            throw new IndexOutOfBoundsException("Invalid version index");
        }
        return timestamps.get(versionIndex);
    }

    public void revertToVersion(int versionIndex) {
        if (versionIndex < 0 || versionIndex >= versions.size()) {
            throw new IndexOutOfBoundsException("Invalid version index");
        }
        while (versions.size() > versionIndex + 1) {
            versions.remove(versions.size() - 1);
            timestamps.remove(timestamps.size() - 1);
        }
    }

    public List<String> getVersions() {
        return new ArrayList<>(versions);
    }

    public List<LocalDateTime> getTimestamps() {
        return new ArrayList<>(timestamps);
    }
}