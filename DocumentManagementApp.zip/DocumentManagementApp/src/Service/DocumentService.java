package Service;

import java.util.*;

public interface DocumentService {
    void createDocument(String documentId, String content);
    void updateDocument(String documentId, String newContent);
    void deleteDocument(String documentId);
    String getDocument(String documentId);
    void revertToVersion(String documentId, int versionIndex);
    List<String> listDocuments();
    List<String> getDocumentHistory(String documentId);
}