package Service;

public interface UserService {
    void createUser(String id, String name, String password);
    void loginUser(String id, String password);
    void logoutUser();
}