package Service.Impl;

import java.util.*;
import java.time.LocalDateTime;
import Entity.*;
import Service.*;

public class DocumentServiceImpl implements DocumentService {
    private final Map<String, Document> documents;
    private final UserServiceImpl userService;

    public DocumentServiceImpl(Map<String, Document> documents, UserServiceImpl userService) {
        this.documents = documents;
        this.userService = userService;
    }

    @Override
    public void createDocument(String documentId, String content) {
        if (documents.containsKey(documentId)) {
            throw new IllegalArgumentException("Document ID already exists");
        }
        User currentUser = userService.getCurrentUser();
        if (currentUser == null) {
            throw new IllegalStateException("No user logged in");
        }
        Document document = new Document(documentId, currentUser.getId(), content);
        documents.put(documentId, document);
        currentUser.addDocument(documentId);
    }

    @Override
    public void updateDocument(String documentId, String newContent) {
        Document document = getOwnedDocument(documentId);
        document.addVersion(newContent);
    }

    @Override
    public void deleteDocument(String documentId) {
        Document document = getOwnedDocument(documentId);
        documents.remove(documentId);
    }

    @Override
    public String getDocument(String documentId) {
        Document document = documents.get(documentId);
        if (document == null) {
            throw new IllegalArgumentException("Document not found");
        }
        return document.getCurrentVersion();
    }

    @Override
    public void revertToVersion(String documentId, int versionIndex) {
        Document document = getOwnedDocument(documentId);
        document.revertToVersion(versionIndex);
    }

    @Override
    public List<String> listDocuments() {
        List<String> documentList = new ArrayList<>();
        for (Document doc : documents.values()) {
            documentList.add(doc.getId() + " (Owner: " + doc.getOwnerId() + " - " + userService.getCurrentUser().getName() + ")");
        }
        return documentList;
    }

    @Override
    public List<String> getDocumentHistory(String documentId) {
        Document document = getOwnedDocument(documentId);
        List<String> history = new ArrayList<>();
        List<String> versions = document.getVersions();
        List<LocalDateTime> timestamps = document.getTimestamps();
        for (int i = 0; i < versions.size(); i++) {
            history.add("Version " + (i + 1) + " (Timestamp: " + timestamps.get(i) + "): " + versions.get(i));
        }
        return history;
    }

    private Document getOwnedDocument(String documentId) {
        User currentUser = userService.getCurrentUser();
        if (currentUser == null) {
            throw new IllegalStateException("No user logged in");
        }
        Document document = documents.get(documentId);
        if (document == null) {
            throw new IllegalArgumentException("Document not found");
        }
        if (!currentUser.ownsDocument(documentId)) {
            throw new IllegalStateException("User does not own the document");
        }
        return document;
    }
}

