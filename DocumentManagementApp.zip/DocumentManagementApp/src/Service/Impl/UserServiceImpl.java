package Service.Impl;

import java.util.*;
import Entity.User;
import Service.UserService;

public class UserServiceImpl implements UserService {
    private final Map<String, User> users;
    private User currentUser;

    public UserServiceImpl(Map<String, User> users) {
        this.users = users;
    }

    @Override
    public void createUser(String id, String name, String password) {
        if (users.containsKey(id)) {
            throw new IllegalArgumentException("User ID already exists");
        }
        users.put(id, new User(id, name, password));
    }

    @Override
    public void loginUser(String id, String password) {
        User user = users.get(id);
        if (user == null || !user.authenticate(password)) {
            throw new IllegalArgumentException("Invalid credentials");
        }
        currentUser = user;
    }

    @Override
    public void logoutUser() {
        currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }
}