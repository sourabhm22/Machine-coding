import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import Service.*;
import Service.Impl.*;
import Entity.*;

public class App {
        private static final Scanner scanner = new Scanner(System.in);
    private static final Map<String, User> users = new HashMap<>();
    private static final Map<String, Document> documents = new HashMap<>();
    private static final UserService userService = new UserServiceImpl(users);
    private static final DocumentService documentService = new DocumentServiceImpl(documents, (UserServiceImpl) userService);

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = Integer.parseInt(scanner.nextLine());
            try {
                switch (choice) {
                    case 1: createUser(); break;
                    case 2: loginUser(); break;
                    case 3: logoutUser(); break;
                    case 4: createDocument(); break;
                    case 5: updateDocument(); break;
                    case 6: deleteDocument(); break;
                    case 7: viewDocument(); break;
                    case 8: revertDocument(); break;
                    case 9: listDocuments(); break;
                    case 10: showDocumentHistory(); break;
                    case 11: {
                        System.out.println("Terminating the application.");
                        return;
                    }
                    default: System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void showMenu() {
        System.out.println("Document Management System");
        System.out.println("1. Create User");
        System.out.println("2. Login User");
        System.out.println("3. Logout User");
        System.out.println("4. Create Document");
        System.out.println("5. Update Document");
        System.out.println("6. Delete Document");
        System.out.println("7. View Document");
        System.out.println("8. Revert Document");
        System.out.println("9. List Documents");
        System.out.println("10. Show Document History");
        System.out.println("11. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void createUser() {
        System.out.print("Enter user ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter user name: ");
        String name = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        userService.createUser(id, name, password);
        System.out.println("User created successfully.");
    }

    private static void loginUser() {
        System.out.print("Enter user ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        userService.loginUser(id, password);
        System.out.println("User logged in successfully.");
    }

    private static void logoutUser() {
        userService.logoutUser();
        System.out.println("User logged out successfully.");
    }

    private static void createDocument() {
        System.out.print("Enter document ID: ");
        String documentId = scanner.nextLine();
        System.out.print("Enter document content: ");
        String content = scanner.nextLine();
        documentService.createDocument(documentId, content);
        System.out.println("Document created successfully.");
    }

    private static void updateDocument() {
        System.out.print("Enter document ID: ");
        String documentId = scanner.nextLine();
        System.out.print("Enter new document content: ");
        String content = scanner.nextLine();
        documentService.updateDocument(documentId, content);
        System.out.println("Document updated successfully.");
    }

    private static void deleteDocument() {
        System.out.print("Enter document ID: ");
        String documentId = scanner.nextLine();
        documentService.deleteDocument(documentId);
        System.out.println("Document deleted successfully.");
    }

    private static void viewDocument() {
        System.out.print("Enter document ID: ");
        String documentId = scanner.nextLine();
        String content = documentService.getDocument(documentId);
        System.out.println("Document content: " + content);
    }

    private static void revertDocument() {
        System.out.print("Enter document ID: ");
        String documentId = scanner.nextLine();
        System.out.print("Enter version index to revert to: ");
        int versionIndex = Integer.parseInt(scanner.nextLine());
        documentService.revertToVersion(documentId, versionIndex);
        System.out.println("Document reverted successfully.");
    }

    private static void listDocuments() {
        List<String> documents = documentService.listDocuments();
        System.out.println("Documents:");
        for (String doc : documents) {
            System.out.println(doc);
        }
    }

    private static void showDocumentHistory() {
        System.out.print("Enter document ID: ");
        String documentId = scanner.nextLine();
        List<String> history = documentService.getDocumentHistory(documentId);
        System.out.println("Document history:");
        for (String entry : history) {
            System.out.println(entry);
        }
    }
    }


