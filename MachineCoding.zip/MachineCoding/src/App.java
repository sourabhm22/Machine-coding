import java.util.*;
import java.util.stream.Collectors;

class User {
    private final String name;
    private final String profession;
    private final Set<String> subscribedTopics;
    private final List<Question> questions;
    private final List<Answer> answers;

    public User(String name, String profession) {
        this.name = name;
        this.profession = profession;
        this.subscribedTopics = new HashSet<>();
        this.questions = new ArrayList<>();
        this.answers = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public Set<String> getSubscribedTopics() {
        return subscribedTopics;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public void subscribe(String... topics) {
        subscribedTopics.addAll(Arrays.asList(topics));
    }

    public void unsubscribe(String... topics) {
        subscribedTopics.removeAll(Arrays.asList(topics));
    }
}

class Question {
    private static int idCounter = 1;
    private final int id;
    private final String content;
    private final User user;
    private final List<String> topics;
    private final Date timestamp;
    private final List<Answer> answers;

    public Question(String content, User user, List<String> topics) {
        this.id = idCounter++;
        this.content = content;
        this.user = user;
        this.topics = topics;
        this.timestamp = new Date();
        this.answers = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public List<String> getTopics() {
        return topics;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public void addAnswer(Answer answer) {
        answers.add(answer);
    }
}

class Answer {
    private final String content;
    private final User user;
    private final Date timestamp;
    private int votes;

    public Answer(String content, User user) {
        this.content = content;
        this.user = user;
        this.timestamp = new Date();
        this.votes = 0;
    }

    public String getContent() {
        return content;
    }

    public User getUser() {
        return user;
    }

    public int getVotes() {
        return votes;
    }

    public void upvote() {
        this.votes++;
    }
}

interface UserService {
    void userSignup(String name, String profession);
    void login(String name);
    void logout();
    void subscribe(String... topics);
}

interface QuestionService {
    void addQuestion(String content, List<String> topics);
    void addAnswer(int questionId, String content);
    void showFeed(List<String> filterTopics);
    void upvoteAnswer(int questionId, int answerIndex);
}

class UserServiceImpl implements UserService {
    private final Map<String, User> users;
    private User loggedInUser;

    public UserServiceImpl() {
        this.users = new HashMap<>();
        this.loggedInUser = null;
    }

    @Override
    public void userSignup(String name, String profession) {
        if (users.containsKey(name)) {
            System.out.println("User already exists.");
            return;
        }
        users.put(name, new User(name, profession));
        System.out.println("User signed up: " + name);
    }

    @Override
    public void login(String name) {
        if (loggedInUser != null) {
            throw new IllegalStateException("Another user is already logged in.");
        }
        if (!users.containsKey(name)) {
            System.out.println("User not found.");
            return;
        }
        loggedInUser = users.get(name);
        System.out.println("User logged in: " + name);
    }

    @Override
    public void logout() {
        if (loggedInUser == null) {
            System.out.println("No user is logged in.");
            return;
        }
        System.out.println("User logged out: " + loggedInUser.getName());
        loggedInUser = null;
    }

    @Override
    public void subscribe(String... topics) {
        if (loggedInUser == null) {
            System.out.println("No user is logged in.");
            return;
        }
        loggedInUser.subscribe(topics);
        System.out.println("User subscribed to topics: " + Arrays.toString(topics));
    }

    public User getLoggedInUser() {
        return loggedInUser;
    }
}

class QuestionServiceImpl implements QuestionService {
    private final List<Question> questions;
    private final UserServiceImpl userService;

    public QuestionServiceImpl(UserServiceImpl userService) {
        this.questions = new ArrayList<>();
        this.userService = userService;
    }

    @Override
    public void addQuestion(String content, List<String> topics) {
        User loggedInUser = userService.getLoggedInUser();
        if (loggedInUser == null) {
            System.out.println("No user is logged in.");
            return;
        }
        Question question = new Question(content, loggedInUser, topics);
        questions.add(question);
        loggedInUser.getQuestions().add(question);
        System.out.println("Question added: " + content);
    }

    @Override
    public void addAnswer(int questionId, String content) {
        User loggedInUser = userService.getLoggedInUser();
        if (loggedInUser == null) {
            System.out.println("No user is logged in.");
            return;
        }
        Question question = questions.stream()
                .filter(q -> q.getId() == questionId)
                .findFirst()
                .orElse(null);
        if (question == null) {
            System.out.println("Question not found.");
            return;
        }
        if (question.getTopics().stream().noneMatch(t -> loggedInUser.getSubscribedTopics().contains(t))) {
            System.out.println("User not subscribed to any topic of the question.");
            return;
        }
        Answer answer = new Answer(content, loggedInUser);
        question.addAnswer(answer);
        loggedInUser.getAnswers().add(answer);
        System.out.println("Answer added: " + content);
    }

    @Override
    public void showFeed(List<String> filterTopics) {
        User loggedInUser = userService.getLoggedInUser();
        if (loggedInUser == null) {
            System.out.println("No user is logged in.");
            return;
        }
        List<Question> feed = questions.stream()
                .filter(q -> filterTopics == null || q.getTopics().stream().anyMatch(filterTopics::contains))
                .collect(Collectors.toList());
        System.out.println("Feed:");
        for (Question q : feed) {
            System.out.println(q.getId() + ". " + q.getContent() + " (" + q.getTopics() + ")");
            for (Answer a : q.getAnswers()) {
                System.out.println("  - " + a.getContent() + " by " + a.getUser().getName() + " (Votes: " + a.getVotes() + ")");
            }
        }
    }

    @Override
    public void upvoteAnswer(int questionId, int answerIndex) {
        User loggedInUser = userService.getLoggedInUser();
        if (loggedInUser == null) {
            System.out.println("No user is logged in.");
            return;
        }
        Question question = questions.stream()
                .filter(q -> q.getId() == questionId)
                .findFirst()
                .orElse(null);
        if (question == null) {
            System.out.println("Question not found.");
            return;
        }
        if (question.getTopics().stream().noneMatch(t -> loggedInUser.getSubscribedTopics().contains(t))) {
            System.out.println("User not subscribed to any topic of the question.");
            return;
        }
        if (answerIndex < 0 || answerIndex >= question.getAnswers().size()) {
            System.out.println("Answer not found.");
            return;
        }
        question.getAnswers().get(answerIndex).upvote();
        System.out.println("Answer upvoted: " + question.getAnswers().get(answerIndex).getContent());
    }
}

public class App {
    private static final Scanner scanner = new Scanner(System.in);
    private static final UserService userService = new UserServiceImpl();
    private static final QuestionService questionService = new QuestionServiceImpl((UserServiceImpl) userService);

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    signup();
                    break;
                case "2":
                    login();
                    break;
                case "3":
                    logout();
                    break;
                case "4":
                    subscribe();
                    break;
                case "5":
                    addQuestion();
                    break;
                case "6":
                    addAnswer();
                    break;
                case "7":
                    showFeed();
                    break;
                case "8":
                    upvoteAnswer();
                    break;
                case "9":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Signup");
        System.out.println("2. Login");
        System.out.println("3. Logout");
        System.out.println("4. Subscribe to topics");
        System.out.println("5. Add question");
        System.out.println("6. Add answer");
        System.out.println("7. Show feed");
        System.out.println("8. Upvote answer");
        System.out.println("9. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void signup() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter profession: ");
        String profession = scanner.nextLine().trim();
        userService.userSignup(name, profession);
    }

    private static void login() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine().trim();
        userService.login(name);
    }

    private static void logout() {
        userService.logout();
    }

    private static void subscribe() {
        System.out.print("Enter topics (comma separated): ");
        String[] topics = scanner.nextLine().trim().split(",");
        userService.subscribe(topics);
    }

    private static void addQuestion() {
        System.out.print("Enter question content: ");
        String content = scanner.nextLine().trim();
        System.out.print("Enter topics (comma separated): ");
        List<String> topics = Arrays.asList(scanner.nextLine().trim().split(","));
        questionService.addQuestion(content, topics);
    }

    private static void addAnswer() {
        System.out.print("Enter question ID: ");
        int questionId = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Enter answer content: ");
        String content = scanner.nextLine().trim();
        questionService.addAnswer(questionId, content);
    }

    private static void showFeed() {
        System.out.print("Enter filter topics (comma separated, leave empty for no filter): ");
        String filterInput = scanner.nextLine().trim();
        List<String> filterTopics = filterInput.isEmpty() ? null : Arrays.asList(filterInput.split(","));
        questionService.showFeed(filterTopics);
    }

    private static void upvoteAnswer() {
        System.out.print("Enter question ID: ");
        int questionId = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Enter answer index: ");
        int answerIndex = Integer.parseInt(scanner.nextLine().trim());
        questionService.upvoteAnswer(questionId, answerIndex);
    }
}
